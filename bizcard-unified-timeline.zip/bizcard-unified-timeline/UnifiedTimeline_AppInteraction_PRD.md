# BizCard 2.0 – Unified Timeline（统一时间流）App 交互 PRD（可落地版）

> **定位**：本 PRD 只覆盖"App 交互与信息架构"，用于指导设计出稿与研发实现 Demo/MVP。  
> **核心原则**：Timeline 是唯一视角（Single Viewport），所有"导航"收敛为"改变观察范围 Scope"。行动（Action）永远优先。
> 
> **最后更新**：2026-01-15

---

## 0. 目标与非目标

### 0.1 版本目标（Demo / MVP）
- **单页首页（Unified Timeline）**：实现 Layer 1-4 的交互框架与核心联动。
- **Scope 模型落地**：搜索/类型/联系人/日期筛选的组合规则、可见反馈、一键回到 All。
- **Action 闭环最小可用**：从卡片抽取/创建 Action → 勾选完成 → 在流里插入 Action Log。
- **Processing 状态**：支持"录音/通话"等内容从 `Processing...` → `Ready` 的状态迁移展示。
- **沿用既有 Timeline 视觉骨架**：时间轴 + Hero Cards（大卡片）+ Micro Dots（小圆点/聚合点）+ 整点锚点 + 按天加载。

### 0.2 非目标（本期不做/可降级）
- 不做完整的多 Tab 导航体系（仅保留"抽屉/弹层"承载低频配置）。
- 不追求端到端 AI 识别准确率（Demo 允许用 mock 数据/可编辑结果），但必须有**纠错/撤销**机制。
- 不做复杂权限/团队协作（先单人）。
- 不保留底部 `Home/Contacts/Actions` Tab：统一收敛到"Timeline 单页 + 弹层/详情页"。

---

## 1. 核心心智模型：Scope（观察范围）而非 Tab（房间）

### 1.1 定义：Scope = "你正在看什么"
Scope 由 4 类约束组成（可组合）：
- **Q（Query）**：关键词搜索（人名/事项/公司/标签）
- **T（Type）**：内容类型（All / Meetings / Agent Calls）
- **P（Person）**：联系人聚焦（支持**多选**，多个 contactId）
- **D（Date Range）**：日期范围（Today / This week / Last 7 Days / All Time）

> **产品表达**：用户不是"切到会议页"，而是把 Timeline 的 Scope 设为 `T=Meetings`。

### 1.2 Scope 优先级与组合规则
- **组合**：Q/T/P/D **允许叠加**（AND 关系），默认并存。
- **多选联系人**：P 支持多选，筛选逻辑为"包含任一选中联系人"（OR 关系）。
- **冲突处理**：
  - 当 `P` 生效时：卡片范围只保留与选中联系人关联的记录
  - 当 `T` 指向单一类型时：只展示该类型卡片；Action Log 仍可展示（作为闭环反馈），但需置灰/弱化
  - `D` 生效时：严格按时间过滤；当过滤后为空，提供"放宽日期"建议入口
- **清除**：每个约束都必须可单独清除；同时提供"一键清空 Scope（回到 All）"

### 1.3 Scope 可感知反馈（防迷路）
- 顶部必须有**语境反馈**：
  - `P` 生效：展示选中联系人 Chips（可多个，可单独移除，可点击进入详情）
  - 仅 `T` 生效：展示类型语境（icon + 文案 + clear）
  - `Q/D` 生效：在 Action Hub Panel 中展示"搜索词/日期范围"胶囊 + clear

---

## 2. 信息架构与页面清单（Demo 必做）

### 2.1 页面（Page）
- **Home – Unified Timeline（首页单页）**
- **Contact Profile（联系人详情）**：从 Context Header 或卡片上的联系人入口进入
- **Meeting Detail（会议/通话详情）**：从 Meeting/Call Card 进入

### 2.2 关键弹层/抽屉（Overlay）
- **Settings Drawer（左侧抽屉）**：包含 Profile、Hardware、Agent、Settings
- **Person Picker（通讯录选择弹层）**：支持多选 + 点击跳转详情
- **Note Modal（笔记输入弹层）**：支持选择 Note 或 Action Item
- **FAB Speed Dial（右下角扇形输入）**

### 2.3 IA 收敛说明（从多 Tab → 单视角）
- **原 Home Tab** → 合并进 **Unified Timeline 默认态（Scope=All）**
- **原 Contacts Tab** → 不作为"首页入口"存在；改为：
  - 在 Timeline 卡片上"按需进入"联系人详情
  - 在 Person Picker 中"选择联系人=改变 Scope（P）"
- **原 Actions Tab** → 被 **Action Hub（吸顶）**取代

---

## 3. 首页交互架构：4 Layer（必须与 Scope 联动）

### 3.1 Layer 1：Global Control（全局控制层，常驻）

**结构**（3 行）：
```
Row 1: [Avatar] [Hardware Status: ● BizCard Pro 🔋85% 📶] [QR Share]
Row 2: [🔍 搜索人/公司/事项...                              ✕]
Row 3: [📍 Meetings] [🤖 Calls] [📅] [👤]
```

- **Avatar**
  - 点击：打开 Settings Drawer
  - 显示：连接状态点
- **Hardware Status**
  - 居中显示：设备名称 + 连接状态 + 电量 + 信号
- **Search Bar**
  - 始终可见，输入即时过滤（300ms debounce）
  - 有内容时显示清除按钮
- **Filter Pills**
  - 与搜索并行显示，支持组合筛选
  - Meetings/Calls：点击切换 Type 筛选
  - 日期：打开日期范围选择器
  - 联系人：打开多选联系人选择器

### 3.2 Layer 2：Context Header（语境头图，仅 Scope 生效时出现）
显示规则：
- 若 `P` 存在（选中联系人）：展示选中联系人 Chips（可多个）
  - 每个 Chip 可单独移除
  - 点击 Chip 可进入联系人详情
  - 提供"Clear All"按钮
- 否则隐藏

### 3.3 Layer 3：Action Hub（行动中枢，吸顶）
显示规则：
- 默认显示折叠态：`X Pending Actions`
- 若 `P` 存在：显示 `X Actions with {Name(s)}`
- 点击折叠条：展开 checklist

展开 Panel 内容：
- Scope Chips：显示当前 Q/T/D 筛选条件
- Action List：每条 Action 显示：
  - 勾选框
  - 标题
  - 关联联系人
  - **关联 Meeting 标题**（可点击跳转详情）
  - **关联日期**

### 3.4 Layer 4：The Stream（垂直时间流，无限滚动）
- 下拉刷新
- 懒加载（分页）
- 按日期分组（JAN 8, 2026 (Today) / JAN 7, 2026 / ...）

---

## 4. 卡片系统（Card Design + 状态机）

### 4.1 卡片类型（Demo 最小集合）

| 类型 | 说明 | 来源标记 |
|------|------|----------|
| **Meeting Card** | 会议记录（录音生成） | Hardware |
| **Agent Call Card** | AI 代理通话 | Agent Call |
| **Business Card（名片卡片）** | 添加的联系人名片 | Scan/NFC/BizCard |
| **Note Card** | 用户手动添加的笔记 | Manual |
| **Action Note Card** | 带待办事项的笔记 | Manual |
| **Action Log** | 系统生成的完成记录 | System |
| **Processing Card** | 处理中状态 | - |
| **Cluster** | 聚合的轻量活动 | System |

### 4.2 Business Card（名片卡片）规范

**统一展示形式**（不再区分 Exchange）：
```
┌──────────────────────────────────────┐
│  [头像]  Alex Turner                 │
│          VP of Sales                 │
│          Acme Corp               ›   │
├──────────────────────────────────────┤
│  📍 CES Main Hall         [SCANNED]  │
└──────────────────────────────────────┘
```

**来源类型标记**：
| 标签 | 含义 | 样式 |
|------|------|------|
| `SCANNED` | 相机扫描添加的普通名片 | 橙色 |
| `NFC` | NFC Tap 添加的名片 | 紫色 |
| `BIZCARD` | 已注册的 BizCard 用户 | 绿色 |

**交互**：
- 点击整个卡片 → 打开联系人详情页

### 4.3 Note Card 规范

**结构**：
```
┌──────────────────────────────────────┐
│  📝 Note                             │
├──────────────────────────────────────┤
│  📍 Current Location                 │
│  Quick Note                          │
│  [笔记内容...]                        │
└──────────────────────────────────────┘
```

**必须包含**：
- 📍 Location（地点）
- 时间戳
- 内容

### 4.4 Action Note Card 规范

**结构**（与 Note 类似，但有红点）：
```
┌──────────────────────────────────────┐
│  ✓ Action Item                   🔴  │
├──────────────────────────────────────┤
│  📍 Current Location                 │
│  [待办内容...]                        │
└──────────────────────────────────────┘
```

**特性**：
- 有红点表示 Pending 状态
- 完成后红点消失
- 同时在 Action Hub 中显示

### 4.5 通用卡片规范
每张卡片必须包含：
- **时间**（发生时间或创建时间）
- **来源**（Hardware / Agent Call / Manual）
- **关联人**（0~N）
- **主标题**
- **摘要**（2-3 行）

### 4.6 Action Log（闭环反馈卡片）
生成时机：Action 被勾选完成

展示规则：
- 文案模板：`✔ Completed: {ActionTitle}`
- 视觉：置灰、较小高度，降低噪音但保持"完成感"

### 4.7 Processing 状态机
状态：
- `Processing`：显示 Skeleton + "Processing..."
- `Ready`：替换为对应卡片
- `Failed`：显示失败提示 + 重试入口

---

## 5. FAB 功能定义

### 5.1 FAB Speed Dial 菜单

| 按钮 | 功能 | 结果 |
|------|------|------|
| 📝 Add Note | 添加笔记 | 打开 Note Modal |
| 📷 Scan Card | 扫描名片 | 创建 Processing → Business Card |
| 🎙️ Quick Record | 快速录音 | 创建 Processing → Meeting Card |

### 5.2 Note Modal 交互

用户输入内容后可选择：
- **Save as Note** → 创建 Note Card（带 Location）
- **Add as Action Item** → 创建 Action Note Card + Action Item

---

## 6. Settings Drawer 结构

### 6.1 布局
```
┌─────────────────────────────┐
│  Settings                 ✕ │
├─────────────────────────────┤
│  MY PROFILE                 │
│  ┌─────────────────────────┐│
│  │ [头像] Brian Roberts    ││
│  │        Product Lead     ││
│  │  Skills: [tags...]      ││
│  │  Needs:  [tags...]      ││
│  └─────────────────────────┘│
│                             │
│  MY HARDWARE                │
│  ┌─────────────────────────┐│
│  │  [E-ink 屏幕预览]        ││
│  │  ● Connected 🔋85% 📶   ││
│  │  ─────────────────────  ││
│  │  NFC ACTION             ││
│  │  bizcard.app/u/brian    ││
│  │  [Personal Profile]     ││
│  │  ─────────────────────  ││
│  │  ⚙ Hardware Settings ›  ││
│  └─────────────────────────┘│
│                             │
│  MY AGENT                   │
│  [🎭 Voice & Knowledge  ›]  │
│                             │
│  ─────────────────────────  │
│  SETTINGS                   │
│  [📡 Bind NFC           ›]  │
│  [🚫 Blocklist          ›]  │
│  [👤 Account Settings   ›]  │
│  [ℹ️ About & Legal   V2.0]  │
└─────────────────────────────┘
```

### 6.2 Hardware Preview
- **E-ink 屏幕预览**：模拟硬件显示效果
- **连接状态**：Connected/Disconnected + 电量 + 信号
- **NFC Action**：当前 NFC 指向的 URL + 备注说明

### 6.3 Settings 项目
- Bind NFC：绑定 NFC 功能
- Blocklist：黑名单管理
- Account Settings：账户管理（含 Log out, Delete Account）
- About & Legal：版本信息、隐私政策、服务条款

---

## 7. 关键交互流程

### 7.1 日常浏览（Morning Check）
1) 进入首页：默认 Scope = All  
2) Layer 3 显示：`X Pending Actions`  
3) 用户向下刷流：浏览卡片  
4) 点击卡片：进入详情

### 7.2 聚焦某人（Deep Dive）
入口：
- 点击卡片上联系人头像
- 或 Layer 1 Person Picker 选择（支持多选）

结果：
- `P` 生效，Layer 2 展开联系人 Chips
- Layer 3 文案切换为 `X Actions with {Name(s)}`
- Layer 4 只保留与选中人关联的卡片

### 7.3 组合筛选
用户可同时：
- 输入搜索关键词
- 选择 Meetings/Calls 类型
- 选择日期范围
- 选择多个联系人

所有条件以 AND 逻辑组合。

### 7.4 添加笔记/待办
1) 点击 FAB → Add Note
2) 输入内容
3) 选择：Save as Note 或 Add as Action Item
4) 生成对应卡片（带 Location）

### 7.5 扫描名片
1) 点击 FAB → Scan Card
2) 创建 Processing Card
3) 完成后替换为 Business Card（带来源标记）

---

## 8. 数据结构

### 8.1 TimelineItem（流条目）
```typescript
interface TimelineItem {
  id: string;
  type: 'meeting' | 'call' | 'card' | 'note' | 'action_note' | 'action_log' | 'processing' | 'cluster';
  timestamp: string;
  source: 'hardware' | 'agent_call' | 'manual';
  title: string;
  summary: string;
  contactIds: string[];
  status: 'processing' | 'ready' | 'failed';
  actions: string[];  // 关联的 action IDs
  meta?: {
    place?: string;           // Location
    source?: 'scan' | 'nfc';  // 名片来源
    isBizCardUser?: boolean;  // 是否 BizCard 用户
    durationMin?: number;     // 时长
    direction?: 'IN' | 'OUT'; // 通话方向
  };
}
```

### 8.2 ActionItem（行动项）
```typescript
interface ActionItem {
  id: string;
  title: string;
  status: 'pending' | 'done';
  relatedContactIds: string[];
  relatedTimelineItemId?: string;
  relatedMeetingTitle?: string;  // 关联的会议标题
  relatedDate?: string;          // 关联日期
  createdAt: string;
  doneAt?: string;
}
```

### 8.3 Scope（观察范围）
```typescript
interface Scope {
  q?: string;              // 搜索关键词
  view?: 'all' | 'meetings' | 'calls';  // 类型筛选
  personIds?: string[];    // 多选联系人
  dateRange?: 'all' | 'today' | 'this_week' | 'last_7';
}
```

---

## 9. 验收标准

### 9.1 Scope 可用性
- 搜索框与筛选条件可同时使用
- 联系人支持多选
- 任意时刻用户可明确知道当前 Scope
- Scope 可单独清除 & 一键清空

### 9.2 卡片系统
- Business Card 统一展示，有来源标记
- Note/Action Note 都有 Location
- 点击联系人头像可进入详情

### 9.3 Action 闭环
- Action Hub 展开可勾选 pending items
- 勾选后在流内生成 Action Log
- Action 点击可跳转到关联 Meeting 详情

### 9.4 Settings
- Drawer 包含 Profile/Hardware/Agent/Settings
- Hardware 有 E-ink 预览和 NFC 信息

---

## 10. Demo 实现（Prototype）

### 10.1 文件结构
```
bizcard-unified-timeline/
├── index.html    # 页面结构
├── styles.css    # 样式（iOS 风格）
├── app.js        # 应用逻辑
├── data.js       # Mock 数据
└── README.md     # 运行说明
```

### 10.2 已实现功能
- [x] iPhone 设备框架
- [x] 状态栏（时间/信号/电量）
- [x] Header（头像/硬件状态/QR）
- [x] 搜索栏（始终可见）
- [x] Filter Pills（可组合筛选）
- [x] Context Header（多选联系人 Chips）
- [x] Action Hub（折叠/展开/关联信息）
- [x] Timeline Stream（按天分组）
- [x] Business Card（带来源标记）
- [x] Note/Action Note Card（带 Location）
- [x] FAB Speed Dial（Note/Scan/Voice）
- [x] Note Modal（Note 或 Action 选择）
- [x] Person Picker（多选 + 详情跳转）
- [x] Contact Detail Modal
- [x] Meeting Detail Modal
- [x] Settings Drawer（Profile/Hardware/Agent/Settings）
- [x] E-ink 屏幕预览
- [x] NFC Action 信息
- [x] Toast 通知

